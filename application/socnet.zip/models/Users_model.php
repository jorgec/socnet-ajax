<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users_model extends CI_Model {

	protected $tbl = 'users';
	protected $pk = 'id';

	public function __construct()
	{
		parent::__construct();
		
	}

	// getters

	public function get( $id )
	{
		$this->db->where( $this->pk, $id );
		return $this->db->get( $this->tbl );
	}

	/**
	 * get_many will return rows based on:
	 * $conditions - see codeigniter db->where()
	 * $limit - see codeigniter db->limit()
	 * $order - see codeigniter db->order_by()
	 *
	 * @return an array of objects
	 */

	public function get_many( $conditions = FALSE, $limit = array(0,10), $order = array( 'id', 'ASC') )
	{
		if( $conditions ){
			$this->db->where( $conditions );
		}
		$this->db->limit = $limit;
		$this->db->order_by( $order[0], $order[1] );
		return $this->db->get( $this->tbl )->result();
	}

	/**
	 * get one based on $conditions
	 *
	 * @return object
	 */
	function get_one( $conditions = FALSE )
	{
		if( ! $conditions ){
			return $this->get_many();
		}
		$this->db->where( $conditions );
		return $this->db->get( $this->tbl )->row();
	    
	}



	// setters
	/**
	 * create
	 *
	 * @return bool
	 * @author 
	 */
	function create($formdata)
	{
		$formdata->created = time();
	    return $this->db->insert( $this->tbl, $formdata );
	}

	/**
	 * generic setter
	 *
	 * @return bool
	 * @author 
	 */
	function set($column, $value, $id)
	{
		$this->db->where( $this->pk, $id );
	    return $this->db->update( $this->tbl, array( $column => $value ) );
	}

	function delete( $id ){
		return $this->set( 'deleted', 1, $id );
	}


	// post getters
	function get_posts($id)
	{
		$this->load->model('posts_model');
		$condition = array( 'user_id' => $id );
		$posts = $this->posts_model->get_many( $condition );

		echo '<pre>'; print_r($posts); echo '</pre>';
	}

	// post setters
	function write_post( $content )
	{
		$this->load->model('posts_model');

		$postdata = new stdClass();
		$postdata->user_id = 2;
		$postdata->content = $content;
		
		return $this->posts_model->create( $postdata );

	}

}

/* End of file Users_model.php */
/* Location: ./application/models/Users_model.php */