<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Register</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		

		<div class="container">
			
			<form action="<?php echo site_url('user/do_register');?>" method="POST" role="form">
				<legend>Registration</legend>
			
				<?php echo $message;?>

				<div class="form-group">
					<label for="">Username</label>
					<input type="text" name="username" class="form-control" id="username" placeholder="jdelacruz" required>
				</div>

				<div class="form-group">
					<label for="">Email</label>
					<input type="email" name="email" class="form-control" id="email" placeholder="name@domain.com" required>
				</div>
				<div class="form-group">
					<label for="">Password</label>
					<input type="password" name="password" class="form-control" id="password" required>
				</div>
				<div class="form-group">
					<label for="">Repeat Password</label>
					<input type="password" name="password2" class="form-control" id="password2" required>
				</div>
			
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>

		</div>



		<!-- jQuery -->
		<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
		
	</body>
</html>